<?php

// URL base de tu API Spring Boot
const API_BASE_URL = "http://localhost:8081/api/v1";