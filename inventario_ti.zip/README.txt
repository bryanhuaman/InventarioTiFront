URL PRINCIPAL:
http://localhost/inventario_ti/public/login.php

CREAR BD EN PHPADMIN
nombre: inventario_ti
cotejamiento: utf8mb4_general_ci

usuario administrador:
admin@correo.com
contraseña:
123
